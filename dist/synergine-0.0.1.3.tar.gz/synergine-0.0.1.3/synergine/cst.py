from synergine.lib.eint import IncrementedNamedInt

COL_ALL = IncrementedNamedInt.get('synergine.col.all')
