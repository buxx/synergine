from synergine.core.connection.Display import Display


class TestDisplay(Display):

    _name = "test"

    def draw_objects(self, objects, point):
        pass

    def terminate(self):
        pass