from synergine.synergy.event.Event import Event


class ContactEvent(Event):
    pass