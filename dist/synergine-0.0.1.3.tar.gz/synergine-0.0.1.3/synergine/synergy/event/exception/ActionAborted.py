class ActionException(Exception):
    pass


class ActionAborted(ActionException):
    pass