class SynergyObjectInterface():
    # TODO: pleins de truc dans SynergyObject qui devrait etre ici ?
    pass