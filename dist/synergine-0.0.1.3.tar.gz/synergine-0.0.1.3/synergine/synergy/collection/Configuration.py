class Configuration():

    def get_start_objects(self, collection):
        return []
