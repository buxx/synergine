from synergine.core.connection.Display import Display


class TestDisplay(Display):
    def start_of_cycle(self):
        pass

    def end_of_cycle(self):
        pass

    def draw_objects(self, objects, point):
        pass