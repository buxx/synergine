class SpaceDataConnector():
    pass