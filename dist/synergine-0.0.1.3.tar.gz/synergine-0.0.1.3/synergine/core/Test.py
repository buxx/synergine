class Test:

    def __init__(self):
        self.foo = 'bar'
        """A foo bar instance attribute !"""