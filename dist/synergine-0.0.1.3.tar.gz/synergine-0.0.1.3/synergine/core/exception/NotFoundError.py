class NotFoundError(Exception):
    pass